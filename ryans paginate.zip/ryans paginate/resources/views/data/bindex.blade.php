<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
  </head>
  <body>
      <div class="container">
    <form action="/data_out" method="post">
        {{csrf_field()}}
        <div class="form-group">
          <label for="name">Name</label>
          <input name="name" type="text" class="form-control" id="name">
        </div>

        <div class="form-group">
                <label for="address">Address</label>
                <input name="address" type="text" class="form-control" id="address">
        </div>

        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <div class="row">
          <h1>simple table </h1>
      <table class="table">
            <tr>
                    <td>ID</td>
                    <td>Name</td>
                    <td>Address</td>
                </tr>
          @foreach($datas as $data)
            <tr>
                <td>{{$data->id}}</td>
                <td>{{$data->name}}</td>
                <td>{{$data->address}}</td>
            </tr>
           @endforeach
      </table>
      </div>
      </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>