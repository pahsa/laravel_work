<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'DataController@index');
Route::get('/data', 'DataController@index');
Route::post('/datainsert', 'DataController@datainsert');
Route::get('/tabs', 'TabsController@index');
Route::get('/showme', 'ShowmeController@index');
Route::get('/simple', 'SimplesController@index');
Route::get('/book', 'BookController@data_te');
Route::post('/data_out', 'BookController@data_in');

Route::get('foo', function () {
    return 'Hello World';
});


Route::get('/test_1', 'Test_1Controller@test_one');
Route::get('/data_pass', 'Test_1Controller@data_out');

// about page.... 

Route::get('/about', 'AboutController@about');
Route::post('/deletedata', 'AboutController@deletedata');


/// Edit ... <page 

Route::get('/editdata/{id}', 'AboutController@editdata');
Route::post('/edit_value', 'AboutController@datain');