<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Onework;

class AboutController extends Controller
{

    public function about(){
        $datas = Onework::orderBy('id','desc')->get();
        return view('data.about',compact('datas'));

    }
    public function deletedata(Request $request){
        $id = $request->id;
        $data = Onework::find($id);
        $data->delete();
         
        return redirect('/about');
    }

    public function editdata($id){
        $data = Onework::find($id);

        return view('data.editdata', compact('data'));

    }

    public function datain(Request $request){
        $id = $request->id;
        $firstname = $request->first_name;
        $lastname = $request->last_name;
        $mobile = $request->mobile;
        $email = $request->email;

        $update = Onework::find($id);
        $update->first_name = $firstname;
        $update->last_name = $lastname;
        $update->mobile = $mobile;
        $update->email = $email;

        $update->save();

        return redirect('/about');


    }
}
