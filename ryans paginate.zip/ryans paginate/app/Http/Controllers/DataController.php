<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Showme;

class DataController extends Controller
{
    public function index(){

        $datas = Showme::orderBy('id','desc')->get();
        return view('data.index',compact('datas'));

    }
    
    public function datainsert(Request $request){
        $name = $request->name;
        $mail = $request->mail;
        $mobile = $request->mobile;
        $sex = $request->sex;

        $showme = new Showme; // making variable for new <row class="">
        
        $showme->name=$name;
        $showme->mail=$mail;
        $showme->mobile=$mobile;
        $showme->sex=$sex;

        $showme->save(); // save data....

        return redirect('/data'); // route...

    }

}
  