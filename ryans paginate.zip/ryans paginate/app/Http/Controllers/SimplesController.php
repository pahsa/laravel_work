<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Simple;

class SimplesController extends Controller
{
    public function index(){
        return simple::all() ;
    }
}
