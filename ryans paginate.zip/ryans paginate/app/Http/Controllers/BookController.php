<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Book;

class BookController extends Controller
{
    public function data_te(){
        $datas = Book::orderBy('id','desc')->get();
        return view('data.bindex',compact('datas'));
    }

    public function data_in(Request $request){
        $name = $request->name;
        $add = $request->address;

        $book = new Book; // gettin table row .. 

        $book->name=$name;
        $book->address=$add;


    
            $book->save(); // save data....
    
            return redirect('/book'); // route...
    }


}

