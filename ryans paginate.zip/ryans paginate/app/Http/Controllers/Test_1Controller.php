<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Onework;

class Test_1Controller extends Controller
{
    public function test_one(){
        $datas = Onework::orderBy('id','desc')->get();
        return view('data.one',compact('datas'));

    }


    public function data_out(Request $request){
        $first_name = $request->firstname;
        $last_name = $request->lastname;
        $mobile = $request->mobile;
        $email = $request->email;

        $onework = new Onework; // gettin table row .. 

        $onework->first_name = $first_name;
        $onework->last_name = $last_name;
        $onework->mobile = $mobile;
        $onework->email = $email;


    
            $onework->save(); // save data....
    
            return redirect('/test_1'); // route...
    }
}
