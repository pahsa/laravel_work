<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Onework extends Model
{
    protected $table = 'oneworks';
}
