<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pasha extends Model
{
    protected $table = 'pasha';
}
