<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Simple extends Model
{
    protected $table = 'simples';
}
