<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Showme extends Model
{
    protected $table = 'showmes';
}
