-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 20, 2018 at 11:31 AM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ryans`
--

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Pahsa', 'Topkhana Road, Dhaka ', '2018-03-20 07:23:56', '2018-03-20 07:23:56'),
(2, 'Masum', 'Mirpur', '2018-03-20 07:32:09', '2018-03-20 07:32:09'),
(3, 'Eva ', 'Lalbag', '2018-03-20 08:13:58', '2018-03-20 08:13:58'),
(4, 'Sharuk', 'Monipur', '2018-03-20 09:58:07', '2018-03-20 09:58:07'),
(5, 'Pasham', 'mm', '2018-03-20 09:58:20', '2018-03-20 09:58:20'),
(6, 'Coffee', 'Dhaka', '2018-03-20 10:16:15', '2018-03-20 10:16:15'),
(7, 'Google', 'Google.com', '2018-03-20 10:39:02', '2018-03-20 10:39:02'),
(8, 'test', 'hbfgkhgkhk', '2018-03-20 11:05:42', '2018-03-20 11:05:42'),
(9, '1', '1', '2018-03-20 11:06:23', '2018-03-20 11:06:23'),
(10, '2', '2', '2018-03-20 11:06:28', '2018-03-20 11:06:28'),
(11, '3', '3', '2018-03-20 11:06:33', '2018-03-20 11:06:33'),
(12, '4', '4', '2018-03-20 11:13:11', '2018-03-20 11:13:11'),
(13, 'Sharuk', 'Mirput', '2018-03-20 11:28:42', '2018-03-20 11:28:42'),
(14, '5', '5', '2018-03-20 11:30:02', '2018-03-20 11:30:02');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_03_19_062742_create_authors_table', 2),
(4, '2018_03_19_082952_create_pasha_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `pasha`
--

CREATE TABLE `pasha` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pasha`
--

INSERT INTO `pasha` (`id`, `title`, `address`, `created_at`, `updated_at`) VALUES
(1, 'pasha', 'B-112 Mohakhali DOHS....\r\n', NULL, NULL),
(2, 'pashax', 'xxxB-112 Mohakhali DOHS....\r\n', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `showmes`
--

CREATE TABLE `showmes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `showmes`
--

INSERT INTO `showmes` (`id`, `name`, `mail`, `mobile`, `sex`, `created_at`, `updated_at`) VALUES
(1, 'Paha', 'pahsa@officextracts.com', '173740444', 'male', NULL, NULL),
(2, 'Masum', 'masum@officextracts.com', '1255', 'Male', NULL, NULL),
(3, 'Eva', 'eva@officextracts.com', '8801525', 'Female', '2018-03-20 06:24:04', '2018-03-20 06:24:04'),
(4, 'Daliya', 'daliya@officextracts.com', '+08801737404444', 'Female', '2018-03-20 00:48:22', '2018-03-20 00:48:22'),
(5, 'Romel', 'romel@officextracts.com', '+08801737404444', 'Female', '2018-03-20 06:50:09', '2018-03-20 06:50:09'),
(6, 'Asis', 'asis@officextracts.com', '55555', 'Male', '2018-03-20 06:51:49', '2018-03-20 06:51:49'),
(7, 'Salman', 'salman@gmail.com', '022455556', 'Male', '2018-03-20 07:39:08', '2018-03-20 07:39:08'),
(8, 'Sharuk', 'sharuk@gmail.com', '554544554', 'Male', '2018-03-20 09:41:11', '2018-03-20 09:41:11');

-- --------------------------------------------------------

--
-- Table structure for table `simples`
--

CREATE TABLE `simples` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `simples`
--

INSERT INTO `simples` (`id`, `name`, `address`, `created_at`, `updated_at`) VALUES
(1, 'pahsa', '', '2018-03-20 05:52:31', '2018-03-20 05:52:31'),
(2, 'pahsa 1', '', '2018-03-20 05:52:31', '2018-03-20 05:52:31'),
(3, 'Asis', 'Mohakhali....', '2018-03-20 06:59:03', '2018-03-20 06:59:03');

-- --------------------------------------------------------

--
-- Table structure for table `tabs`
--

CREATE TABLE `tabs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabs`
--

INSERT INTO `tabs` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'pasha', '2018-03-20 04:52:26', NULL),
(2, 'Masum', '2018-03-20 04:52:32', NULL),
(3, 'Eva', '2018-03-20 04:52:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'pasha', 'pasha@officextracts.com', '123456', '1', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pasha`
--
ALTER TABLE `pasha`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `showmes`
--
ALTER TABLE `showmes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `simples`
--
ALTER TABLE `simples`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabs`
--
ALTER TABLE `tabs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pasha`
--
ALTER TABLE `pasha`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `showmes`
--
ALTER TABLE `showmes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `simples`
--
ALTER TABLE `simples`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tabs`
--
ALTER TABLE `tabs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
